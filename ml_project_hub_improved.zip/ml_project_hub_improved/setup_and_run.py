"""
ML Project Hub - Quick Setup Script
Run this file to automatically set up the project.
Usage: python setup_and_run.py
"""
import subprocess
import sys
import os

def run(cmd, desc=""):
    if desc:
        print(f"\n[*] {desc}...")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"    WARNING: {result.stderr.strip()}")
    else:
        print(f"    OK")
    return result

print("=" * 55)
print("       ML PROJECT HUB - SETUP")
print("=" * 55)

# Install dependencies
run("pip install django scikit-learn pandas numpy --quiet", "Installing dependencies")

# Migrations
run(f"{sys.executable} manage.py migrate", "Running database migrations")

# Create superuser
print("\n[*] Creating admin superuser...")
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mlhub.settings')
try:
    import django
    django.setup()
    from django.contrib.auth.models import User
    if not User.objects.filter(username='admin').exists():
        User.objects.create_superuser('admin', 'admin@mlhub.com', 'admin123')
        print("    Admin created: username=admin | password=admin123")
    else:
        print("    Admin already exists")
except Exception as e:
    print(f"    {e}")

# Pre-train models
print("\n[*] Pre-training ML models (this may take ~30 seconds)...")
try:
    from drug_recommendation.ml_model import train_models
    d = train_models()
    best_drug = max(d['results'], key=d['results'].get)
    print(f"    Drug Model: {best_drug} → {d['results'][best_drug]}%")
except Exception as e:
    print(f"    Drug model warning: {e}")

try:
    from machine_failure.ml_model import train_models as mf_train
    m = mf_train()
    best_mf = max(m['results'], key=m['results'].get)
    print(f"    Machine Failure Model: {best_mf} → {m['results'][best_mf]}%")
except Exception as e:
    print(f"    MF model warning: {e}")

try:
    from chatbot.nlp_engine import load_chatbot
    load_chatbot()
    print("    Chatbot NLP engine: Loaded ✓")
except Exception as e:
    print(f"    Chatbot warning: {e}")

print("\n" + "=" * 55)
print("  SETUP COMPLETE!")
print("=" * 55)
print("  Admin: http://127.0.0.1:8000/admin/")
print("  Login: username=admin  password=admin123")
print("=" * 55)
print("\n  Starting server...")
print("  Visit: http://127.0.0.1:8000\n")

os.execv(sys.executable, [sys.executable, "manage.py", "runserver"])
