# ML Project Hub

A complete Django + Machine Learning web application with 3 AI modules.

## Setup Instructions

### 1. Install Dependencies
```
pip install -r requirements.txt
```

### 2. Run Migrations
```
python manage.py migrate
```

### 3. Create Superuser (Admin)
```
python manage.py createsuperuser
```

### 4. Run the Server
```
python manage.py runserver
```

### 5. Open Browser
Visit: http://127.0.0.1:8000

---

## Modules

### 1. Drug Recommendation System
- Dataset: drug200.csv (200 patient records)
- Algorithms: Decision Tree, Random Forest, SVM, Naive Bayes, Gradient Boosting
- Predicts suitable drug based on Age, Sex, BP, Cholesterol, Na_to_K

### 2. Machine Failure Type Prediction
- Dataset: predictive_maintenance.csv (10,000 records)
- Algorithms: Decision Tree, Random Forest, KNN, Naive Bayes, Gradient Boosting
- Predicts failure type from sensor readings

### 3. AI Chatbot
- Dataset: chatbot_data.csv (836 AI/ML Q&A pairs)
- Engine: TF-IDF + Cosine Similarity NLP
- Interactive chatbot for AI/ML questions

---

## Admin Panel
Visit: http://127.0.0.1:8000/admin/
Use your superuser credentials.

## Tech Stack
- Backend: Django 4.x
- ML: scikit-learn, pandas, numpy
- Frontend: Bootstrap 5, Font Awesome, Chart.js
- Database: SQLite
