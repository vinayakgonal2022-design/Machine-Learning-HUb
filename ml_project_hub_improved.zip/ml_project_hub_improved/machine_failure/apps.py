from django.apps import AppConfig


class MachineFailureConfig(AppConfig):
    name = 'machine_failure'
