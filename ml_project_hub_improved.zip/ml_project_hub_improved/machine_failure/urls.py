from django.urls import path
from . import views

urlpatterns = [
    path('', views.mf_index, name='mf_index'),
    path('predict/', views.mf_predict, name='mf_predict'),
]
