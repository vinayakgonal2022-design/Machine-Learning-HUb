from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .ml_model import predict_failure, get_model_data

@login_required
def mf_index(request):
    model_data = get_model_data()
    results = model_data['results']
    best_name = max(results, key=results.get)
    context = {
        'results': results,
        'best_name': best_name,
        'best_acc': results[best_name],
    }
    return render(request, 'machine_failure/index.html', context)

@login_required
def mf_predict(request):
    if request.method == 'POST':
        try:
            machine_type = request.POST.get('machine_type')
            air_temp = float(request.POST.get('air_temp'))
            process_temp = float(request.POST.get('process_temp'))
            rot_speed = int(request.POST.get('rot_speed'))
            torque = float(request.POST.get('torque'))
            tool_wear = int(request.POST.get('tool_wear'))
            failure_type, results = predict_failure(machine_type, air_temp, process_temp, rot_speed, torque, tool_wear)
            fail_info = {
                'No Failure': ('✅ No Failure', 'The machine is operating normally. No maintenance required at this time.', 'success'),
                'Heat Dissipation Failure': ('🌡️ Heat Dissipation Failure', 'High temperature detected. Check cooling system and ventilation immediately.', 'danger'),
                'Power Failure': ('⚡ Power Failure', 'Electrical anomaly detected. Inspect power supply and circuit connections.', 'warning'),
                'Overstrain Failure': ('⚠️ Overstrain Failure', 'Mechanical overstrain detected. Reduce torque or rotational speed.', 'warning'),
                'Tool Wear Failure': ('🔧 Tool Wear Failure', 'Tool has exceeded wear threshold. Replace tool immediately.', 'danger'),
                'Random Failures': ('❓ Random Failure', 'Unexpected failure detected. Full diagnostic inspection recommended.', 'secondary'),
            }
            f_label, f_desc, f_color = fail_info.get(failure_type, (failure_type, 'Contact maintenance team.', 'dark'))
            best_name = max(results, key=results.get)
            best_acc = results[best_name]
            context = {
                'failure_type': failure_type,
                'f_label': f_label,
                'f_desc': f_desc,
                'f_color': f_color,
                'machine_type': machine_type,
                'air_temp': air_temp,
                'process_temp': process_temp,
                'rot_speed': rot_speed,
                'torque': torque,
                'tool_wear': tool_wear,
                'results': results,
                'best_name': best_name,
                'best_acc': best_acc,
            }
            return render(request, 'machine_failure/result.html', context)
        except Exception as e:
            messages.error(request, f'Prediction error: {str(e)}')
    return redirect('mf_index')
