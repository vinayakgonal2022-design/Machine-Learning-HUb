import pandas as pd
import numpy as np
import os
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from django.conf import settings

MODEL_PATH = os.path.join(settings.BASE_DIR, 'machine_failure', 'mf_model.pkl')

def load_data():
    df = pd.read_csv(os.path.join(settings.DATASETS_DIR, 'predictive_maintenance.csv'))
    return df

def train_models():
    df = load_data()
    le_type = LabelEncoder()
    le_fail = LabelEncoder()
    df['Type_enc'] = le_type.fit_transform(df['Type'])
    df['Failure_enc'] = le_fail.fit_transform(df['Failure Type'])

    features = ['Type_enc', 'Air temperature [K]', 'Process temperature [K]',
                'Rotational speed [rpm]', 'Torque [Nm]', 'Tool wear [min]']
    X = df[features]
    y = df['Failure_enc']

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42, stratify=y)

    models = {
        'Decision Tree': DecisionTreeClassifier(random_state=42),
        'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
        'Naive Bayes': GaussianNB(),
        'K-Nearest Neighbors': KNeighborsClassifier(n_neighbors=5),
        'Gradient Boosting': GradientBoostingClassifier(n_estimators=100, random_state=42),
    }

    results = {}
    best_model = None
    best_acc = 0

    for name, model in models.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        acc = round(accuracy_score(y_test, preds) * 100, 2)
        results[name] = acc
        if acc > best_acc:
            best_acc = acc
            best_model = model

    model_data = {
        'model': best_model,
        'scaler': scaler,
        'le_type': le_type,
        'le_fail': le_fail,
        'results': results,
        'best_acc': best_acc,
    }
    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(model_data, f)
    return model_data

def get_model_data():
    if not os.path.exists(MODEL_PATH):
        return train_models()
    with open(MODEL_PATH, 'rb') as f:
        return pickle.load(f)

def predict_failure(machine_type, air_temp, process_temp, rot_speed, torque, tool_wear):
    data = get_model_data()
    type_enc = data['le_type'].transform([machine_type])[0]
    features = np.array([[type_enc, air_temp, process_temp, rot_speed, torque, tool_wear]])
    features_scaled = data['scaler'].transform(features)
    pred = data['model'].predict(features_scaled)[0]
    failure_type = data['le_fail'].inverse_transform([pred])[0]
    return failure_type, data['results']
