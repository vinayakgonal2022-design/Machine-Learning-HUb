from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .nlp_engine import get_response

@login_required
def chatbot_index(request):
    return render(request, 'chatbot/index.html')

@login_required
def chatbot_api(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            user_message = data.get('message', '').strip()
            if not user_message:
                return JsonResponse({'response': 'Please type a message.'})
            response = get_response(user_message)
            return JsonResponse({'response': response})
        except Exception as e:
            return JsonResponse({'response': f'Error: {str(e)}'})
    return JsonResponse({'error': 'Invalid method'}, status=405)
