from django.urls import path
from . import views

urlpatterns = [
    path('', views.chatbot_index, name='chatbot_index'),
    path('api/', views.chatbot_api, name='chatbot_api'),
]
