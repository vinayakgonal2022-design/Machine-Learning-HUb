"""
Improved NLP Engine for ML Hub Chatbot
Pipeline: Intent detection → Knowledge base → TF-IDF dataset → Smart fallback
"""
import pandas as pd
import os
import re
import random
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from django.conf import settings

# ── Lazy-loaded dataset state ────────────────────────────────────────────────
_chatbot_data = None
_vectorizer   = None
_tfidf_matrix = None

# ── Built-in Knowledge Base ──────────────────────────────────────────────────
KNOWLEDGE_BASE = {
    # Artificial Intelligence
    "what is ai": "Artificial Intelligence (AI) is the simulation of human intelligence in machines, enabling them to perform tasks that typically require human cognition — such as reasoning, learning, pattern recognition, and decision-making. AI powers technologies from voice assistants to medical diagnostics.",
    "what is artificial intelligence": "Artificial Intelligence (AI) is a branch of computer science that builds systems capable of intelligent behaviour. It encompasses machine learning, deep learning, natural language processing, computer vision, and robotics.",
    "who invented ai": "The term 'Artificial Intelligence' was coined by John McCarthy at the Dartmouth Conference in 1956. Other pioneers include Alan Turing (the Turing Test, 1950), Marvin Minsky, Claude Shannon, and Allen Newell.",
    "history of ai": "AI's history begins in the 1950s. Alan Turing proposed the Turing Test in 1950. John McCarthy coined 'Artificial Intelligence' in 1956. The field evolved through symbolic AI, expert systems, the first AI winter, the rise of machine learning, and today's deep learning revolution.",
    "applications of ai": "AI is applied across industries: healthcare (diagnosis, drug discovery), finance (fraud detection, algorithmic trading), autonomous vehicles, recommendation systems (Netflix, Spotify), NLP (translation, chatbots), robotics, and scientific research.",

    # Machine Learning
    "what is machine learning": "Machine Learning (ML) is a subset of AI that enables systems to learn from data and improve automatically without being explicitly programmed. Instead of writing rules, you train models on examples so they discover patterns on their own.",
    "what is ml": "Machine Learning (ML) is a branch of AI where algorithms learn patterns from data to make predictions or decisions. The three main paradigms are supervised learning, unsupervised learning, and reinforcement learning.",
    "types of machine learning": "Three main types: (1) Supervised Learning — trained on labelled data for classification or regression. (2) Unsupervised Learning — discovers hidden patterns in unlabelled data via clustering or dimensionality reduction. (3) Reinforcement Learning — an agent learns by interacting with an environment to maximise cumulative rewards.",
    "supervised learning": "Supervised learning trains a model on labelled input-output pairs so it learns to map inputs to the correct outputs. Common algorithms include linear regression, decision trees, SVM, and neural networks. Examples: spam detection, house price prediction.",
    "unsupervised learning": "Unsupervised learning finds patterns in data without labelled examples. Techniques include clustering (K-Means, DBSCAN), dimensionality reduction (PCA, t-SNE), and anomaly detection.",
    "reinforcement learning": "Reinforcement Learning (RL) trains an agent to make decisions by rewarding correct actions and penalising incorrect ones. It is used in game-playing AI (AlphaGo, OpenAI Five), robotics, and autonomous systems.",
    "overfitting": "Overfitting occurs when a model learns the training data too well — including its noise — and performs poorly on new, unseen data. It is mitigated using regularisation (L1/L2), dropout, cross-validation, early stopping, and collecting more data.",
    "underfitting": "Underfitting happens when a model is too simple to capture the underlying patterns in data, resulting in poor performance on both training and test sets. Solutions include using a more complex model, adding more features, or reducing regularisation.",

    # Deep Learning
    "what is deep learning": "Deep Learning is a subset of machine learning that uses multi-layered neural networks (deep neural networks) to learn hierarchical representations directly from raw data — images, audio, or text — without manual feature engineering.",
    "deep learning vs machine learning": "Machine learning uses algorithms that rely on manually engineered features, while deep learning automatically learns features through layered neural networks. Deep learning excels at unstructured data (images, speech, text) but requires more data and computational power.",
    "deep learning applications": "Deep learning drives: image and speech recognition, machine translation, autonomous vehicles, medical image analysis, drug discovery, generative AI (art, music, text), and large language models such as GPT and Claude.",

    # Neural Networks
    "what is a neural network": "A neural network is a computing model inspired by the human brain. It consists of layers of interconnected nodes (neurons). Input layers receive data, hidden layers learn representations, and output layers produce predictions. It is the core architecture of deep learning.",
    "what is neural network": "A neural network is a system of artificial neurons arranged in layers that learn to recognise patterns. Given enough data and training, neural networks can approximate virtually any function, powering modern AI.",
    "convolutional neural network": "A CNN (Convolutional Neural Network) is designed for grid-structured data like images. Convolutional layers automatically detect local features (edges, textures, shapes), pooling layers reduce dimensionality, and fully connected layers output predictions. CNNs are the backbone of computer vision.",
    "cnn": "A CNN uses convolutional filters to automatically learn spatial features from images. They are used for image classification, object detection, face recognition, and medical imaging. Notable architectures include VGG, ResNet, and Inception.",
    "rnn": "A Recurrent Neural Network (RNN) processes sequential data by maintaining a hidden state across time steps. It is used for time-series forecasting, language modelling, and speech recognition, though it struggles with long-range dependencies.",
    "lstm": "Long Short-Term Memory (LSTM) is an advanced RNN that solves the vanishing gradient problem using input, forget, and output gates to control information flow. It handles long sequences effectively and is used in NLP, speech, and time-series tasks.",
    "transformer": "The Transformer, introduced in the 2017 paper 'Attention Is All You Need', is a neural network architecture based entirely on self-attention mechanisms. It is the foundation of modern language models: BERT, GPT, T5, Claude, and most state-of-the-art NLP systems.",
    "gpt": "GPT (Generative Pre-trained Transformer) is a large language model architecture from OpenAI trained on massive text corpora. It generates coherent, contextually relevant text and powers applications in writing assistance, coding, summarisation, and Q&A.",

    # NLP
    "what is nlp": "Natural Language Processing (NLP) is a branch of AI that enables computers to understand, interpret, and generate human language. It underpins chatbots, machine translation, sentiment analysis, text summarisation, search engines, and voice assistants.",
    "natural language processing": "NLP combines linguistics, statistics, and machine learning to process text and speech. Core tasks include tokenisation, part-of-speech tagging, named entity recognition, sentiment analysis, machine translation, and question answering.",
    "nlp applications": "NLP powers: virtual assistants (Siri, Alexa, Google), machine translation (Google Translate), spam detection, sentiment analysis, search engines, text summarisation, information extraction, medical record analysis, and chatbots like this one.",
    "sentiment analysis": "Sentiment analysis uses NLP to detect the emotional tone of text — positive, negative, or neutral. It is widely applied in social media monitoring, customer feedback analysis, product review mining, and brand reputation management.",
    "tokenization": "Tokenisation splits raw text into smaller units called tokens (words, subwords, or characters). It is the first step in any NLP pipeline, converting unstructured text into a format that models can process.",
    "word embeddings": "Word embeddings are dense vector representations of words that encode semantic relationships. Similar words have similar vectors. Popular methods: Word2Vec, GloVe, and FastText. Modern transformers use contextualised embeddings (BERT, GPT).",
    "bert": "BERT (Bidirectional Encoder Representations from Transformers) is Google's language model that reads text in both directions to deeply understand context. It set new benchmarks across NLP tasks including question answering, text classification, and named entity recognition.",

    # Computer Vision
    "what is computer vision": "Computer Vision is a field of AI that enables machines to interpret and understand visual information from images and videos. Using deep learning (especially CNNs), it performs tasks like object detection, face recognition, image segmentation, and scene understanding.",
    "object detection": "Object detection identifies and localises objects within an image or video by drawing bounding boxes and assigning class labels. Popular algorithms: YOLO, Faster R-CNN, SSD. Applications include autonomous driving, security surveillance, and retail checkout.",
    "image classification": "Image classification assigns a single label to an entire image (e.g., 'cat' or 'dog'). Deep learning models like ResNet, VGG, and EfficientNet achieve near-human accuracy on benchmark datasets like ImageNet.",
    "image segmentation": "Image segmentation classifies every pixel in an image. Semantic segmentation labels pixels by class; instance segmentation distinguishes individual objects. Used in medical imaging, satellite analysis, and autonomous vehicles.",

    # Data Science
    "what is data science": "Data Science is an interdisciplinary field combining statistics, programming, and domain expertise to extract actionable insights from data. The pipeline includes data collection, cleaning, exploration (EDA), modelling, evaluation, and visualisation.",
    "data science vs machine learning": "Data Science is the broader discipline covering data collection, exploration, analysis, visualisation, and communication. Machine Learning is a specialised technique within data science focused on building predictive models.",
    "what is big data": "Big Data refers to datasets too large or complex for traditional processing tools. Defined by the 4 Vs: Volume (scale), Velocity (speed), Variety (formats), and Veracity (reliability). Processed with Apache Spark, Hadoop, and cloud platforms.",
    "data preprocessing": "Data preprocessing transforms raw, messy data into a clean format suitable for ML models. Key steps: handling missing values, removing duplicates, encoding categorical variables, feature scaling (normalisation/standardisation), and outlier treatment.",
    "feature engineering": "Feature engineering uses domain knowledge to create, transform, or select input variables that improve ML model performance. It is often the most impactful step in building effective models.",
    "exploratory data analysis": "Exploratory Data Analysis (EDA) is the process of visually and statistically exploring a dataset to understand its structure, distributions, correlations, and anomalies before modelling. Tools include Pandas, Matplotlib, and Seaborn.",

    # Python
    "what is python": "Python is a high-level, interpreted, dynamically-typed programming language prized for its clean syntax and readability. It is the dominant language in AI, ML, and data science thanks to its vast ecosystem of libraries and active community.",
    "python for machine learning": "Python's ML ecosystem: Scikit-learn (classical ML), TensorFlow & Keras (deep learning), PyTorch (research-friendly DL), NumPy (numerical computing), Pandas (data manipulation), Matplotlib/Seaborn (visualisation), and Jupyter Notebooks (interactive development).",
    "python libraries for data science": "Key Python libraries for data science: NumPy (arrays, maths), Pandas (data frames), Matplotlib & Seaborn (charts), SciPy (statistics), Scikit-learn (ML algorithms), Statsmodels (statistical models), and Plotly (interactive visualisation).",
    "what is pandas": "Pandas is Python's primary data manipulation library. It provides DataFrame and Series structures for loading, cleaning, filtering, transforming, and analysing tabular data — the workhorse of every data scientist's toolkit.",
    "what is numpy": "NumPy (Numerical Python) is the foundational library for scientific computing in Python. It provides efficient n-dimensional arrays, mathematical functions, linear algebra, and random number generation — used by virtually every other ML/data science library.",
    "what is tensorflow": "TensorFlow is Google's open-source deep learning framework. It supports building and training neural networks at scale, offers the high-level Keras API for ease of use, and supports deployment on CPUs, GPUs, TPUs, and mobile devices.",
    "what is pytorch": "PyTorch is Meta's open-source deep learning framework known for its intuitive dynamic computation graph ('eager mode'). It is the framework of choice for AI research and is widely used in both academia and industry.",
    "what is scikit learn": "Scikit-learn is Python's most comprehensive classical machine learning library. It provides consistent APIs for classification, regression, clustering, dimensionality reduction, model selection, and preprocessing — perfect for rapid prototyping.",
    "what is keras": "Keras is a high-level neural network API that runs on top of TensorFlow. It simplifies building and training deep learning models with a user-friendly interface, making it ideal for beginners and rapid experimentation.",

    # Algorithms
    "what is a decision tree": "A decision tree is a tree-shaped model that makes decisions by recursively splitting data based on feature values. Each internal node tests a feature, each branch is an outcome, and each leaf is a prediction. Interpretable and handles both classification and regression.",
    "random forest": "Random Forest is an ensemble method that builds many decision trees on random subsets of data and features, then combines predictions by voting (classification) or averaging (regression). It is robust, handles high-dimensional data, and resists overfitting.",
    "what is svm": "A Support Vector Machine (SVM) finds the optimal hyperplane that separates classes with the maximum margin. It is effective for high-dimensional spaces and can handle non-linear boundaries using the kernel trick (RBF, polynomial kernels).",
    "support vector machine": "SVM is a powerful supervised learning algorithm that works by finding the decision boundary maximising the margin between classes. With kernel functions, it can classify non-linearly separable data by projecting it to a higher-dimensional space.",
    "k means": "K-Means clustering partitions data into K groups by iteratively assigning each point to the nearest centroid and updating centroids until convergence. It is fast and scalable but requires specifying K and is sensitive to initial centroids.",
    "gradient descent": "Gradient Descent is the core optimisation algorithm in ML. It minimises the loss function by iteratively updating parameters in the direction of the negative gradient. Variants: Stochastic GD (SGD), Mini-batch GD, Adam, RMSProp, and AdaGrad.",
    "backpropagation": "Backpropagation is the algorithm that trains neural networks. It computes gradients of the loss function with respect to all weights using the chain rule, propagating errors backward from the output layer, enabling weight updates via gradient descent.",
    "cross validation": "Cross-validation evaluates how well a model generalises to unseen data. In k-fold CV, the data is split into k folds; the model trains on k-1 folds and tests on the remaining fold, repeated k times to produce a reliable performance estimate.",
    "logistic regression": "Logistic regression is a supervised classification algorithm that models the probability of class membership using the sigmoid function. Despite its name, it is a classifier, not a regressor. It is interpretable, fast, and widely used in industry.",
    "linear regression": "Linear regression models the linear relationship between input features and a continuous output by minimising the sum of squared errors. It is one of the simplest and most interpretable ML algorithms, ideal for regression tasks.",
    "naive bayes": "Naïve Bayes is a probabilistic classifier based on Bayes' theorem with a strong independence assumption between features. It is fast, requires little data, and performs well for text classification and spam detection despite its simplicity.",
    "knn": "K-Nearest Neighbours (KNN) classifies a point based on the majority class of its K closest neighbours in the training set. It requires no explicit training but is computationally expensive at inference time on large datasets.",
    "gradient boosting": "Gradient Boosting builds an ensemble of weak learners (usually decision trees) sequentially, with each tree correcting the errors of the previous. Implementations like XGBoost, LightGBM, and CatBoost are among the most powerful ML algorithms for tabular data.",
    "xgboost": "XGBoost (Extreme Gradient Boosting) is a highly optimised, scalable gradient boosting library. It is known for winning numerous Kaggle competitions and excels on structured/tabular data due to its speed, regularisation, and handling of missing values.",
    "pca": "Principal Component Analysis (PCA) is a dimensionality reduction technique that projects data onto the directions of maximum variance (principal components). It reduces computational cost, removes noise, and enables data visualisation in 2D or 3D.",
    "dropout": "Dropout is a regularisation technique for neural networks where random neurons are deactivated during each training step. This prevents neurons from co-adapting and forces the network to learn more robust, independent features, reducing overfitting.",
    "batch normalisation": "Batch Normalisation normalises the inputs of each layer across a mini-batch during training. It stabilises learning, allows higher learning rates, reduces sensitivity to initialisation, and acts as a mild regulariser.",

    # General Technology
    "what is cloud computing": "Cloud computing delivers computing resources — servers, storage, databases, networking, software — over the internet on demand. Providers like AWS, Azure, and Google Cloud enable scalable, cost-effective ML training and deployment.",
    "what is iot": "The Internet of Things (IoT) is a network of internet-connected physical devices embedded with sensors that collect and exchange data. AI and ML analyse IoT data for predictive maintenance, smart homes, healthcare wearables, and industrial automation.",
    "what is api": "An API (Application Programming Interface) is a contract that lets software components communicate. In ML, models are commonly deployed as REST APIs so that applications can send data and receive predictions in real-time.",
    "what is gpu": "A GPU (Graphics Processing Unit) performs thousands of parallel computations simultaneously. Originally designed for graphics rendering, GPUs have become essential for training deep learning models due to their massive parallelism. NVIDIA's CUDA platform is the industry standard.",
    "what is edge ai": "Edge AI deploys AI models directly on edge devices (smartphones, IoT sensors, cameras) rather than in the cloud. It enables real-time inference with low latency, reduced bandwidth use, and enhanced data privacy.",

    # Greetings / Chit-chat
    "how are you": "I'm doing great, thank you for asking! 😊 I'm your ML Hub AI Assistant, ready to answer questions about AI, Machine Learning, Data Science, NLP, Computer Vision, and more. What would you like to explore today?",
    "who are you": "I'm the ML Hub AI Assistant — an intelligent chatbot trained on AI and Machine Learning topics. I can explain concepts, algorithms, frameworks, and applications across the entire AI/ML domain. Ask me anything!",
    "what can you do": "I can answer questions about: Artificial Intelligence, Machine Learning, Deep Learning, Neural Networks, NLP, Computer Vision, Data Science, Python libraries, and ML algorithms. Try asking 'What is machine learning?' or 'Explain gradient descent.'",
    "thank you": "You're very welcome! 😊 Feel free to ask more questions anytime.",
    "thanks": "Happy to help! 🙌 Is there anything else you'd like to know about AI or ML?",
    "bye": "Goodbye! 👋 It was great chatting with you. Come back anytime to keep learning about AI and ML!",
    "goodbye": "See you soon! 👋 Keep exploring the fascinating world of Artificial Intelligence!",
}

GREETING_RESPONSES = [
    "👋 Hello! I'm your **ML Hub AI Assistant**. I'm here to help you explore AI, Machine Learning, Deep Learning, NLP, Computer Vision, and more. What would you like to learn today?",
    "Hi there! 😊 Welcome to ML Hub. I'm trained on AI and Machine Learning topics. Feel free to ask me anything — from 'What is deep learning?' to 'How does backpropagation work?'",
    "Hey! 👋 Great to see you! I'm your AI assistant specialised in Machine Learning and Data Science. What topic are you curious about today?",
    "Hello! Welcome aboard! 🤖 I can explain AI concepts, ML algorithms, neural networks, NLP, and much more. What's on your mind?",
]

FALLBACK_RESPONSES = [
    "That's an interesting question! While I don't have a specific answer for that, I specialise in AI, Machine Learning, Deep Learning, NLP, Computer Vision, and Data Science. Could you rephrase, or ask something in those areas?",
    "I'm not sure I have a precise answer for that query. I work best explaining AI and ML concepts — neural networks, algorithms, Python libraries, and data science techniques. Try rephrasing or asking something else!",
    "Hmm, I couldn't find a confident answer for that. My knowledge is focused on Artificial Intelligence and Machine Learning. Feel free to ask about deep learning, NLP, computer vision, or any ML algorithm!",
    "I'm still learning! I didn't quite catch that one. I'm best with questions about AI, ML, data science, Python, and related technologies. Could you try a different question?",
]


# ── Helpers ───────────────────────────────────────────────────────────────────

def clean_text(text):
    text = text.lower().strip()
    text = re.sub(r"[^\w\s]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text


def normalise_query(text):
    mapping = {
        r"\bml\b": "machine learning",
        r"\bdl\b": "deep learning",
        r"\bai\b": "artificial intelligence",
        r"\bnlp\b": "natural language processing",
        r"\bcv\b": "computer vision",
        r"\bnn\b": "neural network",
        r"\brnn\b": "recurrent neural network",
        r"\bsvn\b": "support vector machine",
        r"\bknn\b": "k nearest neighbours",
        r"\brf\b": "random forest",
    }
    for pattern, replacement in mapping.items():
        text = re.sub(pattern, replacement, text)
    return text


def is_greeting(text):
    greetings = {"hi", "hello", "hey", "hiya", "howdy", "sup", "whats up",
                 "good morning", "good afternoon", "good evening", "good day"}
    cleaned = clean_text(text)
    words = set(cleaned.split())
    return bool(words & greetings) or cleaned in greetings


def keyword_lookup(query):
    cleaned = clean_text(query)
    normalised = normalise_query(cleaned)

    # Exact match
    for q in (normalised, cleaned):
        if q in KNOWLEDGE_BASE:
            return KNOWLEDGE_BASE[q]

    # Substring match — longest key wins
    best_key, best_len = None, 0
    for key in KNOWLEDGE_BASE:
        if (key in normalised or key in cleaned) and len(key) > best_len:
            best_key, best_len = key, len(key)
    if best_key:
        return KNOWLEDGE_BASE[best_key]

    # Token overlap — ignore stop words to avoid false positives
    STOP = {"what", "is", "a", "an", "the", "are", "how", "does", "do",
            "can", "could", "tell", "me", "about", "explain", "define",
            "describe", "give", "please", "i", "want", "know"}
    q_tokens = set(normalised.split()) - STOP
    if q_tokens:  # only match if meaningful tokens remain
        best_overlap, best_match_key = 0, None
        for key in KNOWLEDGE_BASE:
            k_tokens = set(key.split()) - STOP
            overlap = len(q_tokens & k_tokens)
            if overlap > best_overlap and overlap >= 1:
                best_overlap, best_match_key = overlap, key
        if best_match_key:
            return KNOWLEDGE_BASE[best_match_key]

    return None


# ── Dataset loader ────────────────────────────────────────────────────────────

def load_chatbot():
    global _chatbot_data, _vectorizer, _tfidf_matrix
    if _chatbot_data is not None:
        return
    try:
        df = pd.read_csv(os.path.join(settings.DATASETS_DIR, "chatbot_data.csv"))
        df.dropna(inplace=True)
        df.columns = [c.strip() for c in df.columns]
        df = df[df["Question"].str.len() > 10]
        df = df[df["Answer"].str.len() > 5]
        df = df.reset_index(drop=True)
        _chatbot_data = df
        _vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            min_df=1,
            max_df=0.95,
        )
        _tfidf_matrix = _vectorizer.fit_transform(df["Question"].tolist())
    except Exception:
        _chatbot_data = pd.DataFrame(columns=["Question", "Answer"])
        _vectorizer = None
        _tfidf_matrix = None


def dataset_lookup(query):
    load_chatbot()
    if _vectorizer is None or _chatbot_data.empty:
        return None, 0.0
    cleaned = clean_text(normalise_query(query))
    try:
        user_vec = _vectorizer.transform([cleaned])
        sims = cosine_similarity(user_vec, _tfidf_matrix).flatten()
        best_idx = int(np.argmax(sims))
        score = float(sims[best_idx])
        if score < 0.25:
            return None, score
        answer = str(_chatbot_data.iloc[best_idx]["Answer"]).strip().replace("\\n", " ")
        if len(answer) < 8:
            return None, 0.0
        return answer, score
    except Exception:
        return None, 0.0


# ── Main entry point ──────────────────────────────────────────────────────────

def get_response(user_input):
    """
    Pipeline:
      1. Greeting intent  → warm greeting
      2. Knowledge base   → curated answer
      3. TF-IDF dataset   → dataset answer (score >= 0.25)
      4. Smart fallback
    """
    if not user_input or not user_input.strip():
        return "Please type a question about AI or Machine Learning."

    raw = user_input.strip()

    if is_greeting(raw):
        return random.choice(GREETING_RESPONSES)

    kb_answer = keyword_lookup(raw)
    if kb_answer:
        return kb_answer

    ds_answer, score = dataset_lookup(raw)
    if ds_answer:
        return ds_answer

    return random.choice(FALLBACK_RESPONSES)
