import pandas as pd
import numpy as np
import os
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from django.conf import settings

MODEL_PATH = os.path.join(settings.BASE_DIR, 'drug_recommendation', 'drug_model.pkl')

def load_data():
    df = pd.read_csv(os.path.join(settings.DATASETS_DIR, 'drug200.csv'))
    return df

def train_models():
    df = load_data()
    le_sex = LabelEncoder()
    le_bp = LabelEncoder()
    le_chol = LabelEncoder()
    le_drug = LabelEncoder()

    df['Sex_enc'] = le_sex.fit_transform(df['Sex'])
    df['BP_enc'] = le_bp.fit_transform(df['BP'])
    df['Cholesterol_enc'] = le_chol.fit_transform(df['Cholesterol'])
    df['Drug_enc'] = le_drug.fit_transform(df['Drug'])

    X = df[['Age', 'Sex_enc', 'BP_enc', 'Cholesterol_enc', 'Na_to_K']]
    y = df['Drug_enc']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    models = {
        'Decision Tree': DecisionTreeClassifier(random_state=42),
        'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
        'Naive Bayes': GaussianNB(),
        'SVM': SVC(kernel='rbf', random_state=42),
        'Gradient Boosting': GradientBoostingClassifier(random_state=42),
    }

    results = {}
    best_model = None
    best_acc = 0

    for name, model in models.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        acc = round(accuracy_score(y_test, preds) * 100, 2)
        results[name] = acc
        if acc > best_acc:
            best_acc = acc
            best_model = model

    model_data = {
        'model': best_model,
        'le_sex': le_sex,
        'le_bp': le_bp,
        'le_chol': le_chol,
        'le_drug': le_drug,
        'results': results,
        'best_acc': best_acc,
    }
    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(model_data, f)
    return model_data

def get_model_data():
    if not os.path.exists(MODEL_PATH):
        return train_models()
    with open(MODEL_PATH, 'rb') as f:
        return pickle.load(f)

def predict_drug(age, sex, bp, cholesterol, na_to_k):
    data = get_model_data()
    sex_enc = data['le_sex'].transform([sex])[0]
    bp_enc = data['le_bp'].transform([bp])[0]
    chol_enc = data['le_chol'].transform([cholesterol])[0]
    features = np.array([[age, sex_enc, bp_enc, chol_enc, na_to_k]])
    pred = data['model'].predict(features)[0]
    drug = data['le_drug'].inverse_transform([pred])[0]
    return drug, data['results']
