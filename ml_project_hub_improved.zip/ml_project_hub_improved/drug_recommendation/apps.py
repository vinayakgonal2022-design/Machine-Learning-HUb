from django.apps import AppConfig


class DrugRecommendationConfig(AppConfig):
    name = 'drug_recommendation'
