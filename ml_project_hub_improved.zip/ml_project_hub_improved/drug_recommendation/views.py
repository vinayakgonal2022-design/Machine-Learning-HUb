from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .ml_model import predict_drug, get_model_data

@login_required
def dashboard(request):
    return render(request, 'dashboard/index.html')

@login_required
def drug_index(request):
    model_data = get_model_data()
    results = model_data['results']
    best_name = max(results, key=results.get)
    context = {
        'results': results,
        'best_name': best_name,
        'best_acc': results[best_name],
    }
    return render(request, 'drug_recommendation/index.html', context)

@login_required
def drug_predict(request):
    if request.method == 'POST':
        try:
            age = int(request.POST.get('age'))
            sex = request.POST.get('sex')
            bp = request.POST.get('bp')
            cholesterol = request.POST.get('cholesterol')
            na_to_k = float(request.POST.get('na_to_k'))
            drug, results = predict_drug(age, sex, bp, cholesterol, na_to_k)
            drug_info = {
                'DrugY': ('Drug Y', 'Recommended for patients with high Na_to_K ratio (> 14-15). Effective for managing sodium-potassium imbalance.', 'success'),
                'drugA': ('Drug A', 'Suitable for female patients with HIGH blood pressure. Works best for hypertensive female patients.', 'primary'),
                'drugB': ('Drug B', 'Suitable for male patients with HIGH blood pressure. Works best for hypertensive male patients.', 'info'),
                'drugC': ('Drug C', 'Recommended for patients with LOW blood pressure. Helps stabilize blood pressure levels.', 'warning'),
                'drugX': ('Drug X', 'General recommendation for patients with NORMAL blood pressure. Balanced medication.', 'secondary'),
            }
            d_name, d_desc, d_color = drug_info.get(drug, (drug, 'Consult your physician for details.', 'dark'))
            best_name = max(results, key=results.get)
            best_acc = results[best_name]
            context = {
                'drug': drug,
                'drug_name': d_name,
                'drug_desc': d_desc,
                'drug_color': d_color,
                'age': age, 'sex': sex, 'bp': bp, 'cholesterol': cholesterol, 'na_to_k': na_to_k,
                'results': results,
                'best_name': best_name,
                'best_acc': best_acc,
            }
            return render(request, 'drug_recommendation/result.html', context)
        except Exception as e:
            messages.error(request, f'Error: {str(e)}')
    return redirect('drug_index')
