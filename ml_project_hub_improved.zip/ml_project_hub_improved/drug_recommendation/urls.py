from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('drug/', views.drug_index, name='drug_index'),
    path('drug/predict/', views.drug_predict, name='drug_predict'),
]
